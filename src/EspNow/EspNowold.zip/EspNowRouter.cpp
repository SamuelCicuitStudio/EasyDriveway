// EspNowRouter.cpp
#include "EspNowRouter.h"
#include "EspNowStack.h"   // Stack::send(..)
#include <string.h>

#ifndef NOW_ROUTER_LOG
  #define NOW_ROUTER_LOG(...)  do{}while(0)
#endif

namespace espnow {

bool Router::requiresTopo(uint8_t msg_type) {
  switch (msg_type) {
    case NOW_MSG_CTRL_RELAY:    // physical topology sensitive
    case NOW_MSG_CONFIG_WRITE:  // topology-scoped configuration
    case NOW_MSG_TOPO_PUSH:     // explicit topology ops
      return true;
    default:
      return false;
  }
}

RouteResult Router::route(const uint8_t srcMac[6], const Packet& in, Stack& stack) {
  // Find adapter for our local role
  IRoleAdapter* a = adapterFor(_localRole);
  if (!a) {
    NOW_ROUTER_LOG("[NOW][ROUTER] No adapter for local role=%u\n", (unsigned)_localRole);
    return RouteResult::NO_ADAPTER;
  }

  // Policy: topology-bound ops must carry HAS_TOPO
  if (requiresTopo(in.hdr->msg_type) && !(in.hdr->flags & NOW_FLAGS_HAS_TOPO)) {
    NOW_ROUTER_LOG("[NOW][ROUTER] Policy reject (HAS_TOPO missing) for op=0x%02X\n", (unsigned)in.hdr->msg_type);
    return RouteResult::POLICY;
  }

  // Hand off to the adapter
  Packet out{};
  const bool hasReply = a->handle(srcMac, in, out);
  if (!hasReply) {
    if (!seenUnimpl(in.hdr->msg_type)) {
      markUnimpl(in.hdr->msg_type);
      NOW_ROUTER_LOG("[NOW][ROUTER] Unimplemented op=0x%02X by role=%u\n",
                     (unsigned)in.hdr->msg_type, (unsigned)a->role());
    }
    return RouteResult::UNIMPLEMENTED;
  }

  // Send reply if adapter returned one
  if (out.len > 0 && out.hdr) {
    const bool reliable = (out.hdr->flags & NOW_FLAGS_RELIABLE) != 0;
    stack.send(srcMac, out, reliable);
  }
  return RouteResult::OK;
}

} // namespace espnow
