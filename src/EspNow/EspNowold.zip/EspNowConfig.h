#pragma once
#include <stdint.h>

class NvsManager; // fwd

namespace espnow {


} // namespace espnow
