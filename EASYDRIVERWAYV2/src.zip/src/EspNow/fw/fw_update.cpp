// fw/fw_update.cpp
// Declarations-only unit. Add implementations in this file.

#include "EspNowStack.h"

namespace espnow {
  // (intentionally empty — implement here)
}
