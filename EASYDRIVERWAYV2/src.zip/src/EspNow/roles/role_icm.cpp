// roles/role_icm.cpp
// Declarations-only unit. Add implementations in this file.

#include "EspNowStack.h"\n#include "Hardware_ICM.h"

namespace espnow {
  // (intentionally empty — implement here)
}
