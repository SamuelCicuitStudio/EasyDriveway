// roles/role_semu.cpp
// Declarations-only unit. Add implementations in this file.

#include "EspNowStack.h"\n#include "Hardware_SEMU.h"

namespace espnow {
  // (intentionally empty — implement here)
}
