// roles/role_rel.cpp
// Declarations-only unit. Add implementations in this file.

#include "EspNowStack.h"\n#include "Hardware_REL.h"

namespace espnow {
  // (intentionally empty — implement here)
}
