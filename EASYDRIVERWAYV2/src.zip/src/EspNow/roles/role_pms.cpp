// roles/role_pms.cpp
// Declarations-only unit. Add implementations in this file.

#include "EspNowStack.h"\n#include "Hardware_PMS.h"

namespace espnow {
  // (intentionally empty — implement here)
}
